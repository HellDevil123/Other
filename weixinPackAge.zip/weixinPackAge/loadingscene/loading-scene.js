var createImage = function (sprite, url, cb) {
  cc.textureUtil.loadImage(url, function (err, image) {
    if (cc.isValid(sprite.node) == false) return;

    let frame = new cc.SpriteFrame(image);
    sprite.spriteFrame = frame;
    cb && cb(sprite);
  })
}
//cc.view.setDesignResolutionSize(750, 1334,cc.ResolutionPolicy.FIXED_WIDTH);

var scene = new cc.Scene();
console.log(scene);

let visibleSize = cc.view.getVisibleSize();

//1.新增Canvas组件
var root = new cc.Node();
root.name = 'Canvas';
var canvas = root.addComponent(cc.Canvas);
root.parent = scene;

var bgSpriteNode = new cc.Node();
bgSpriteNode.parent = root;
var bgSprite = bgSpriteNode.addComponent(cc.Sprite);
createImage(bgSprite, "loadingscene/background.png");

let pos = cc.v2(0, -200);

let loadingBgNode = new cc.Node();
loadingBgNode.parent = root;
loadingBgNode.position = pos;
let loadingBgSprite = loadingBgNode.addComponent(cc.Sprite);
createImage(loadingBgSprite, 'loadingscene/loadingBg.png');

let loadingBarNode = new cc.Node();
loadingBarNode.parent = root;
loadingBarNode.position = pos;
let loadingBarSprite = loadingBarNode.addComponent(cc.Sprite);
createImage(loadingBarSprite, 'loadingscene/loadingBar.png', function (sprite) {
  sprite.type = cc.Sprite.Type.FILLED;
  sprite.fillType = cc.Sprite.FillType.HORIZONTAL;
  sprite.fillStart = 0;
  sprite.fillRange = 0;
});

//新增进度条的label
var labelNode = new cc.Node();
labelNode.position = pos;
var label = labelNode.addComponent(cc.Label);
label.fontSize = 30;
label.color = cc.color(0, 0, 0, 255);
label.lineHeight = label.fontSize;
label.string = '资源加载中...0%'
labelNode.parent = root;

//3.预加载场景
scene.loadinglaunchScene = function (launchScene) {
  cc.director.preloadScene(launchScene, (completedCount, totalCount, item) => {
    //todo 这个地方加载精度条
    loadingBarSprite.fillRange = completedCount / totalCount;
    label.string = ("资源加载中..." + parseInt((completedCount / totalCount) * 100) + "%")
  }, (error) => {
    if (error) {
      //todo 这个地方提示网络环境不好，请检查网络后重试
      console.log('==preloadScene error==', launchScene, error)
      label.string = '加载失败,请检查网络';
      return;
    }
    cc.director.loadScene(launchScene, null, function () {
      if (cc.sys.isBrowser) {
        // show canvas
        var canvas = document.getElementById('GameCanvas');
        canvas.style.visibility = '';
        var div = document.getElementById('GameDiv');
        if (div) {
          div.style.backgroundImage = '';
        }
      }
      //cc.view.setDesignResolutionSize(750, 1334,cc.ResolutionPolicy.FIXED_WIDTH);
      cc.loader.onProgress = null;
      console.log('Success to load scene: ' + launchScene);
    });
  })
}

module.exports = scene;