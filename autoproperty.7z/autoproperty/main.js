'use strict';

module.exports = {
  load () {
    // execute when package loaded
    console.log("load package success");
  },

  unload () {
    // execute when package unloaded
  },

  // register your ipc messages here
  messages: {
  },
};