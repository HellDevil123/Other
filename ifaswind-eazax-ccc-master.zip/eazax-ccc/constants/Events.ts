
/**
 * 屏幕调整事件
 */
export const VIEW_RESIZE = 'view-resize';
