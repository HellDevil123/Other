(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Helloworld.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld', __filename);
// Script/Helloworld.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.url = "http://zywxgames.com:20477/switch";
        _this.label_context = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        this.label_context.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label_context.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label_context.string = "点击按钮发送请求";
        //this.label_context.node.color = cc.color(255,0,0,0);
    };
    Helloworld.prototype.RequestButtonOnClick = function () {
        var xhr = cc.loader.getXMLHttpRequest();
        this.streamXHREventsToLabel(xhr, "GET", this.label_context);
        xhr.open("GET", this.url, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); //string
        xhr.send();
    };
    Helloworld.prototype.streamXHREventsToLabel = function (xhr, responseHandler, label) {
        var handler = responseHandler || function (response) {
            return " Response (30 chars): " + response.substring(0, 30) + "...";
        };
        // console event
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status >= 200) {
                console.log(xhr.responseText);
                label.string = xhr.responseText; //string
                var test = JSON.parse(xhr.responseText); //json => [{},{},{}...]
                for (var i = 0; i < test.length; ++i) {
                    console.log(test[i].name);
                    console.log(test[i].page);
                    console.log(test[i].icon);
                }
            }
            else if (xhr.status === 404) {
                console.log("404 page not found!");
            }
            else if (xhr.readyState === 3) {
                console.log("Request dealing!");
            }
            else if (xhr.readyState === 2) {
                console.log("Request received!");
            }
            else if (xhr.readyState === 1) {
                console.log("Server connection established! Request hasn't been received");
            }
            else if (xhr.readyState === 0) {
                console.log("Request hasn't been initiated!");
            }
        };
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "label_context", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Helloworld.js.map
        