const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    private url:string = "http://zywxgames.com:20477/switch";

    @property(cc.Label)
    label_context:cc.Label = null;

    start(){
        this.label_context.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.label_context.verticalAlign = cc.Label.VerticalAlign.CENTER;
        this.label_context.string = "点击按钮发送请求";
        //this.label_context.node.color = cc.color(255,0,0,0);
    }
    RequestButtonOnClick(){
        let xhr = cc.loader.getXMLHttpRequest();
        this.streamXHREventsToLabel(xhr,"GET",this.label_context);
        xhr.open("GET", this.url, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");//string
        xhr.send();
    }
    streamXHREventsToLabel( xhr,responseHandler,label) {
        let handler = responseHandler || function (response) {
            return " Response (30 chars): " + response.substring(0, 30) + "...";
        };
        
        // console event
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status >= 200) {
                console.log(xhr.responseText);
                label.string = xhr.responseText;//string
                let test = JSON.parse(xhr.responseText);//json => [{},{},{}...]
                for(let i = 0; i < test.length; ++i){
                    console.log(test[i].name);
                    console.log(test[i].page);
                    console.log(test[i].icon);
                }
            }
            else if (xhr.status === 404) {
                console.log("404 page not found!");
            }
            else if (xhr.readyState === 3) {
                console.log("Request dealing!");
            }
            else if (xhr.readyState === 2) {
                console.log("Request received!");
            }
            else if (xhr.readyState === 1) {
                console.log("Server connection established! Request hasn't been received");
            }
            else if (xhr.readyState === 0) {
                console.log("Request hasn't been initiated!");
            }
        };
    }
}
