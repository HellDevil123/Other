package org.cocos2dx.javascript;
import com.tykmcsdk.McSdkApplication;
public class MyApplication extends McSdkApplication{
    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();

        System.out.println("===appinit===");
    }
}
