package com.tyksdkdemo.activity;

import com.tykmcsdk.McSdkManager;
import com.tykmcsdk.McUIManager;
import com.tykmcsdk.publicInterface.ChGgListener;
import com.tykmcsdk.publicInterface.ExitListener;
import com.tykmcsdk.publicInterface.PayListener;
import com.tyksdk.zmdemo.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	 EditText et;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_test);

		
	
		// ��ʼ�� 
		McSdkManager.getInstance().activityInit(this);
		
	
		
		initUi();
	

		orderQuery();

		System.out.println("��ǰ���ֵ:"+McSdkManager.getInstance().getGGValue());
		
		System.out.println("==MainActivity=oncreate=");
		
		Toast.makeText(this, ":"+McSdkManager.getInstance().getLanguageType(), Toast.LENGTH_LONG).show();
		
	}
	
	public void printlog(String str){
//		ReflectMethodUtil.callReflectMethod("com.wpp.yjtool.util.tool.McSdkManager", "ipLog", str, String.class);
	
		System.out.println("diao yong fanshe");
	}
	
	int gooditemnum=0;
	public void initUi(){
		
			
			Button bt = (Button) findViewById(R.id.button1);
			bt.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					McSdkManager.getInstance().mcpay(3, (float) 1, "����1",
							new PayListener() {
								
								@Override
								public void onSuccess(int arg0) {
									// TODO Auto-generated method stub
									McUIManager.getInstance().toastShow("֧���ɹ����ŵ���");
									System.out.println("֧���ɹ����ŵ���");
									gooditemnum++;
									TextView tv=findViewById(R.id.textView333);
									tv.setText(""+gooditemnum);
								}
								
								@Override
								public void onFalse(int arg0) {
									// TODO Auto-generated method stub
									McUIManager.getInstance().toastShow("֧��ʧ��");
									// TODO Auto-generated method stub
									System.out.println("֧��ʧ��");
								}
								
								@Override
								public void onCancel(int arg0) {
									// TODO Auto-generated method stub
									McUIManager.getInstance().toastShow("֧��ȡ��");
									// TODO Auto-generated method stub
									System.out.println("֧��ȡ��");
								}
							});
				}
			});
			Button bt2 = (Button) findViewById(R.id.button2);
			bt2.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					McSdkManager.getInstance().hengfObj(null);
					// TODO Auto-generated method stub
					
				}
			});
			Button bt3 = (Button) findViewById(R.id.button3);
			bt3.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					McSdkManager.getInstance().cpingObg(null);
				
				}
			});
			Button bt5 = (Button) findViewById(R.id.button5);
			bt5.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					
					
						// TODO Auto-generated method stub
						McSdkManager.getInstance().spingObj(new ChGgListener() {
							
							@Override
							public void onGgShow() {
								// TODO Auto-generated method stub
							
								Toast.makeText(MainActivity.this, "�ۿ�������Ƶ��ý�������", Toast.LENGTH_LONG).show();
							}
							
							@Override
							public void onFailed(String arg0) {
								// TODO Auto-generated method stub
								System.out.println("��Ƶʧ��");
								
								Toast.makeText(MainActivity.this, "��ʱû����Ƶ����", Toast.LENGTH_LONG).show();
							}
							
							@Override
							public void onCompleteAward() {
								// TODO Auto-generated method stub
								System.out.println("һ�������ﲥ����Ϸ��ŵ���");
								
								Toast.makeText(MainActivity.this, "������Ƶ���ŵ���", Toast.LENGTH_LONG).show();
							}
							
							/**
							 * 
							 */
							@Override
							public void onClose(boolean hasfinish) {
								// TODO Auto-generated method stub
								System.out.println("��Ƶ�ر�");
								System.out.println("hasfinish��ʾ����Ƶ�Ƿ��Ѿ��������");
								if (!hasfinish) {
									Toast.makeText(MainActivity.this, "û��������棬�޷���ý�������", Toast.LENGTH_LONG).show();
								}
								
							}
							
							@Override
							public void onClick() {
								// TODO Auto-generated method stub
								
							}
						});
					
					
					
					
				}
			});
		
			Button bt6 = (Button) findViewById(R.id.button6);

			bt6.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					System.out.println("push--");
					McSdkManager.getInstance().more();
					
				}
			});
	}
	
	//����Ҫ�ĵط�����������������ж�����ѯ����
	public void orderQuery() {
		System.err.println("������ѯ����");
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				System.err.println("������ѯ����1");
				McSdkManager.getInstance().doQuery(new PayListener() {
					/**
					 * onSuccess �������i����֧�����߶�����id���
					 */
					@Override
					public void onSuccess(int i) {
						// TODO Auto-generated method stub
						orderQueryAward(i);
					}
					
					@Override
					public void onFalse(int arg0) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void onCancel(int arg0) {
						// TODO Auto-generated method stub
						
					}
				});
		
			}
		}, 2000);
	}

	/**
	 * ֧��id���
	 * 
	 * @param i
	 */
	public void orderQueryAward(int i) {
		switch (i) {
		case 0:
			Toast.makeText(MainActivity.this, "���ŵ���A", Toast.LENGTH_LONG)
					.show();
			break;
		case 1:
			Toast.makeText(MainActivity.this, "���ŵ���b", Toast.LENGTH_LONG)
					.show();
			break;
		case 2:
			Toast.makeText(MainActivity.this, "���ŵ���c", Toast.LENGTH_LONG)
					.show();
			break;
		case 3:
			Toast.makeText(MainActivity.this, "���ŵ���d", Toast.LENGTH_LONG)
					.show();
			break;

		default:
			break;
		}
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		System.out.println("onResume");
		McSdkManager.getInstance().onResume();
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();

		McSdkManager.getInstance().onPause();
	}

	@Override
	public void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		McSdkManager.getInstance().onStart();
	}
	
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		System.out.println("onStop");
		McSdkManager.getInstance().onStop();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		McSdkManager.getInstance().onNewIntentInvoked(intent);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		System.out.println("onDestroy");
		McSdkManager.getInstance().onDestroy();
	}

	@Override
	public void onRestart() {
		
		super.onRestart();
		
	}
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		McSdkManager.getInstance().onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == 4) {
			McSdkManager.getInstance().exit(new ExitListener() {
				
				@Override
				public void onExit() {
					// TODO Auto-generated method stub
					System.out.println("exit====");
				}
				
				@Override
				public void onCancel() {
					// TODO Auto-generated method stub
					System.out.println("cancel====");
				}
			});
		
			return false;
		}
		return super.onKeyDown(keyCode, event);

	}


}
