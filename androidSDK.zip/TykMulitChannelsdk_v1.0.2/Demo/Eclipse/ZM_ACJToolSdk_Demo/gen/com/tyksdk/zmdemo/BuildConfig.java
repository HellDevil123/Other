/** Automatically generated file. DO NOT MODIFY */
package com.tyksdk.zmdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}